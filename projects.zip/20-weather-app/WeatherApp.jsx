import { useState } from "react";

export default function WeatherApp() {
  const [weather, setWeather] = useState(null);
  const [city, setCity] = useState("");

  const fetchWeather = async () => {
    const res = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=28.61&longitude=77.23&current_weather=true`
    );
    const data = await res.json();
    setWeather(data.current_weather);
  };

  return (
    <div>
      <h2>Weather Forecast</h2>
      <input value={city} onChange={(e) => setCity(e.target.value)} />
      <button onClick={fetchWeather}>Get Weather</button>
      {weather && <p>Temperature: {weather.temperature}°C</p>}
    </div>
  );
}
