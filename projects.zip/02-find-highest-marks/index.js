const marks = [72, 85, 91, 66, 88, 95, 79];
console.log("Highest Marks:", Math.max(...marks));
