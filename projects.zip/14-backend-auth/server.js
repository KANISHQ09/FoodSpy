const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const app = express();
app.use(express.json());

let users = [];

app.post("/register", async (req, res) => {
  const hashed = await bcrypt.hash(req.body.password, 10);
  users.push({ email: req.body.email, password: hashed });
  res.json({ success: true });
});

app.post("/login", async (req, res) => {
  const user = users.find((u) => u.email === req.body.email);
  if (!user) return res.status(400).json({ error: "User not found" });
  const valid = await bcrypt.compare(req.body.password, user.password);
  if (!valid) return res.status(400).json({ error: "Invalid password" });
  const token = jwt.sign({ email: user.email }, "secret");
  res.json({ token });
});

app.listen(3000, () => console.log("Auth API running on 3000"));
