export default function Portfolio() {
  return (
    <div>
      <h1>My Portfolio</h1>
      <p>Hi, I'm Kanishq – Web Developer & AI Enthusiast 🚀</p>
      <ul>
        <li>Projects: Student Directory, To-Do App, Notes App...</li>
        <li>Skills: React, Node.js, MongoDB</li>
        <li>Contact: kanishq@example.com</li>
      </ul>
    </div>
  );
}
